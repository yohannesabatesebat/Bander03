"""
Flight DW course project - data preprocessing
=============================================
Input : fact table (600 rows) + 8 dimension tables (xlsx)
Output: preprocessed fact table, patched dimensions, audit/check sheets

Run:  python preprocess_dw.py <input_dir> <output_dir>
All random choices use a fixed seed, so the result is reproducible.
"""
import sys, os
import numpy as np
import pandas as pd

IN_DIR  = sys.argv[1] if len(sys.argv) > 1 else "."
OUT_DIR = sys.argv[2] if len(sys.argv) > 2 else "./out"
os.makedirs(OUT_DIR, exist_ok=True)

# ------------------------------------------------------------------ parameters
SEED = 2026
STOPOVER_SHARE = 0.5          # share of flights (TicketID) that get a stopover; 1.0 = every flight
NO_STOP_ID = 0                # AirportID of the dummy member "No stopover" (avoids NULL FKs)
USE_NO_STOP_MEMBER = True     # False -> non-stop flights keep NULL in Transit_ariportID
# Candidate transit airports on the Beijing(PEK,74) <-> Shanghai(SHA,22) corridor.
# Chosen from the Airport dimension: each lies close to the great-circle line (detour <= ~9 %)
# and is >150 km away from both end points.
TRANSIT_POOL = {37: "TNA Jinan", 3: "TAO Qingdao", 99: "XUZ Xuzhou",
                147: "NKG Nanjing", 157: "LYI Linyi"}
# Planes allowed for a ~1200 km trunk route: 124-348 seats, no A380, no generic "JET"
PLANE_POOL = [1, 2, 6, 7, 9, 10, 12, 14, 15, 17, 19]

rng = np.random.default_rng(SEED)

def read(name, **kw):
    # keep_default_na=False so literal strings such as "NA" are not turned into NaN
    return pd.read_excel(os.path.join(IN_DIR, name), keep_default_na=False,
                         na_values=[""], **kw)

fact    = read("fact_table_group_2.xlsx")
airport = read("DW_Dim_Airport.xlsx")
airline = read("DW_Dim_Airlines.xlsx")
plane   = read("DW_Dim_Plane.xlsx")
seat    = read("DW_Dim_Seat.xlsx")
prange  = read("DW_Dim_PriceRange.xlsx")
pax     = read("DW_Dim_Passenger.xlsx")
ticket  = read("DW_Dim_ticket.xlsx")

orig = fact.copy()
log = []   # (step, description, rows_affected)

# ------------------------------------------------------------------ 1. stopovers
# A stopover belongs to the FLIGHT, so every passenger on the same TicketID shares it.
tickets = np.sort(fact["TicketID"].unique())
n_stop = int(round(STOPOVER_SHARE * len(tickets)))
stop_tickets = rng.choice(tickets, size=n_stop, replace=False)
transit_ids = np.array(list(TRANSIT_POOL.keys()))
transit_of = {t: int(rng.choice(transit_ids)) for t in sorted(stop_tickets)}
empty = NO_STOP_ID if USE_NO_STOP_MEMBER else pd.NA
fact["Transit_ariportID"] = fact["TicketID"].map(transit_of).fillna(empty).astype("Int64")
log.append(("1 Stopover", f"Transit_ariportID filled: {n_stop} of {len(tickets)} flights get a stopover "
            f"({len(TRANSIT_POOL)} transit airports); the rest = {'0 (No stopover member)' if USE_NO_STOP_MEMBER else 'NULL'}",
            int((fact['Transit_ariportID'] != NO_STOP_ID).sum()) if USE_NO_STOP_MEMBER else int(fact['Transit_ariportID'].notna().sum())))

# dummy member in Airport dimension
airport_new = airport.copy()
if USE_NO_STOP_MEMBER:
    airport_new = pd.concat([pd.DataFrame([{"AirportID": NO_STOP_ID, "ariport": "无经停(No stopover)",
                                            "airportCode": "---", "Ariport_X": np.nan,
                                            "Ariport_y": np.nan, "city": "无"}]),
                             airport_new], ignore_index=True)

# ------------------------------------------------------------------ 2. PlaneID
# One aircraft per flight (TicketID). Keep existing values; fill the rest.
ticket_airline = fact[["TicketID"]].drop_duplicates().merge(
    ticket[["TicketID", "FlightNo"]], on="TicketID", how="left")
ticket_airline["code"] = ticket_airline["FlightNo"].str[:2]
known = (fact.dropna(subset=["PlaneID"])[["TicketID", "PlaneID"]].drop_duplicates()
         .merge(ticket_airline, on="TicketID"))
known_by_airline = known.groupby("code")["PlaneID"].apply(lambda s: sorted(set(int(x) for x in s))).to_dict()
plane_of = {int(r.TicketID): int(r.PlaneID) for r in known.itertuples()}
for r in ticket_airline.itertuples():
    if r.TicketID in plane_of:
        continue
    pool = known_by_airline.get(r.code, PLANE_POOL)       # same airline -> same fleet seen in the data
    plane_of[int(r.TicketID)] = int(rng.choice(pool))
fact["PlaneID"] = fact["TicketID"].map(plane_of).astype("Int64")
log.append(("2 PlaneID", "PlaneID was blank in 536 rows; filled per flight (existing values kept, "
            "airline fleet respected where known)", int(orig["PlaneID"].isna().sum())))

# ------------------------------------------------------------------ 3. CabinID (seat)
# Class (F/C/Y) of the original seat is kept; every passenger on a flight gets a DIFFERENT seat.
cls_of = seat.set_index("CabinID")["CabinClass"]
seats_by_cls = {c: g["CabinID"].to_numpy() for c, g in seat.groupby("CabinClass")}
new_cabin = pd.Series(index=fact.index, dtype="Int64")
for tid, g in fact.groupby("TicketID"):
    cls = cls_of[int(g["CabinID"].iloc[0])]
    new_cabin.loc[g.index] = rng.choice(seats_by_cls[cls], size=len(g), replace=False)
fact["CabinID"] = new_cabin.astype("Int64")
log.append(("3 CabinID", "only 2 distinct seats (325, 1294) were used by all 600 rows; re-assigned a "
            "distinct seat per passenger within each flight, cabin class (Y/C) preserved", len(fact)))

# ------------------------------------------------------------------ 4. PriceRangeID
def price_range(p):
    hit = prange[(prange.MinNum <= p) & (p < prange.MaxNum)]
    return int(hit["PriceRangeID"].iloc[0])
pr_new = fact["Price"].map(price_range)
changed_pr = int((pr_new != orig["PriceRangeID"]).sum())
fact["PriceRangeID"] = pr_new
log.append(("4 PriceRangeID", "recomputed from Price with [MinNum, MaxNum) - only 68/600 original values "
            "matched the price", changed_pr))

# ------------------------------------------------------------------ 5. orphan passengers
missing = sorted(set(fact["PassengerID"]) - set(pax["PassengerID"]))
pax_new = pax.copy()
if missing:
    ph = pd.DataFrame({"PassengerID": missing})
    for c in pax.columns:
        if c != "PassengerID":
            ph[c] = np.nan
    ph["PassengerGender"] = "未知"
    ph["PassengerWorkplace"] = "未知"
    ph["PassengerName"] = "未知(Unknown)"
    pax_new = pd.concat([pax_new, ph[pax.columns]], ignore_index=True).sort_values("PassengerID")
log.append(("5 Passenger FK", f"{len(missing)} PassengerIDs in the fact table were not in the Passenger "
            f"dimension ({missing}); added as 'Unknown' placeholder members so no fact row is lost", len(missing)))

# ------------------------------------------------------------------ 6. Airline link via Ticket
code2id = airline.set_index("airlinesCode")["AirlinesID"].to_dict()
ticket_new = ticket.copy()
ticket_new["AirlinesID"] = ticket_new["FlightNo"].str[:2].map(code2id).astype("Int64")
unmapped = int(ticket_new["AirlinesID"].isna().sum())
log.append(("6 Ticket -> Airline", f"added AirlinesID to the Ticket dimension (FlightNo prefix -> "
            f"Dim_Airlines.airlinesCode); unmapped tickets: {unmapped}", len(ticket_new) - unmapped))

# ------------------------------------------------------------------ checks
def hav(lon1, lat1, lon2, lat2):
    p = np.pi / 180
    a = np.sin((lat2-lat1)*p/2)**2 + np.cos(lat1*p)*np.cos(lat2*p)*np.sin((lon2-lon1)*p/2)**2
    return 2 * 6371 * np.arcsin(np.sqrt(a))

ap = airport.set_index("AirportID")
checks = []
def chk(name, ok, detail=""):
    checks.append({"check": name, "result": "PASS" if ok else "FAIL", "detail": detail})

chk("Row count unchanged", len(fact) == len(orig), f"{len(fact)} rows")
chk("PlaneID has no blanks", fact.PlaneID.notna().all(), f"{fact.PlaneID.nunique()} distinct planes")
chk("CabinID has no blanks", fact.CabinID.notna().all(), f"{fact.CabinID.nunique()} distinct seats")
chk("Seat unique within a flight", not fact.duplicated(["TicketID", "CabinID"]).any())
chk("One plane per flight", (fact.groupby("TicketID").PlaneID.nunique() == 1).all())
chk("One transit per flight", (fact.groupby("TicketID").Transit_ariportID.nunique() == 1).all())
chk("Transit differs from origin/destination",
    not (fact.Transit_ariportID.isin(fact.Departure_ariportID) & (fact.Transit_ariportID != NO_STOP_ID)).any())
chk("FK Departure/Landing/Transit -> Airport",
    fact[["Departure_ariportID", "Landing_ariportID"]].stack().isin(airport_new.AirportID).all() and
    fact.Transit_ariportID.dropna().isin(airport_new.AirportID).all())
chk("FK Passenger", fact.PassengerID.isin(pax_new.PassengerID).all())
chk("FK Ticket", fact.TicketID.isin(ticket.TicketID).all())
chk("FK Plane", fact.PlaneID.isin(plane.PlaneID).all())
chk("FK Cabin(Seat)", fact.CabinID.isin(seat.CabinID).all())
chk("FK PriceRange", fact.PriceRangeID.isin(prange.PriceRangeID).all())
chk("Price within its PriceRange", ((fact.Price >= fact.PriceRangeID.map(prange.set_index('PriceRangeID').MinNum)) &
                                    (fact.Price < fact.PriceRangeID.map(prange.set_index('PriceRangeID').MaxNum))).all())
chk("Every Ticket has an AirlinesID", unmapped == 0)

# ------------------------------------------------------------------ stopover summary
st = fact[fact.Transit_ariportID != NO_STOP_ID] if USE_NO_STOP_MEMBER else fact[fact.Transit_ariportID.notna()]
rows = []
for tid, cnt in st.groupby("Transit_ariportID").size().items():
    tid = int(tid)
    legs = []
    for d in (74, 22):
        legs.append(hav(ap.loc[d, "Ariport_X"], ap.loc[d, "Ariport_y"], ap.loc[tid, "Ariport_X"], ap.loc[tid, "Ariport_y"]))
    rows.append({"Transit_ariportID": tid, "Transit airport": TRANSIT_POOL[tid],
                 "flights": st[st.Transit_ariportID == tid].TicketID.nunique(), "fact rows (segments)": int(cnt),
                 "PEK->transit km (great circle)": round(legs[0]), "transit->SHA km (great circle)": round(legs[1]),
                 "via distance km": round(legs[0] + legs[1]),
                 "detour vs PEK-SHA direct": round((legs[0] + legs[1]) / hav(ap.loc[74, 'Ariport_X'], ap.loc[74, 'Ariport_y'],
                                                                             ap.loc[22, 'Ariport_X'], ap.loc[22, 'Ariport_y']), 3)})
stop_summary = pd.DataFrame(rows)

# ------------------------------------------------------------------ audit (before / after)
audit = pd.DataFrame({
    "ian": orig["ian"], "TicketID": orig["TicketID"],
    "Transit_old": orig["Transit_ariportID"], "Transit_new": fact["Transit_ariportID"],
    "PlaneID_old": orig["PlaneID"], "PlaneID_new": fact["PlaneID"],
    "CabinID_old": orig["CabinID"], "CabinID_new": fact["CabinID"],
    "PriceRangeID_old": orig["PriceRangeID"], "PriceRangeID_new": fact["PriceRangeID"]})

# ------------------------------------------------------------------ write
fact_out = fact[orig.columns]          # identical column names/order as the given fact table
changelog = pd.DataFrame(log, columns=["step", "what was done", "rows affected"])
with pd.ExcelWriter(os.path.join(OUT_DIR, "fact_table_preprocessed.xlsx"), engine="openpyxl") as w:
    fact_out.to_excel(w, sheet_name="Fact_Preprocessed", index=False)
    changelog.to_excel(w, sheet_name="Change_Log", index=False)
    stop_summary.to_excel(w, sheet_name="Stopover_Summary", index=False)
    pd.DataFrame(checks).to_excel(w, sheet_name="Checks", index=False)
    audit.to_excel(w, sheet_name="Audit_Before_After", index=False)
airport_new.to_excel(os.path.join(OUT_DIR, "DW_Dim_Airport_preprocessed.xlsx"), index=False)
pax_new.to_excel(os.path.join(OUT_DIR, "DW_Dim_Passenger_preprocessed.xlsx"), index=False)
ticket_new.to_csv(os.path.join(OUT_DIR, "DW_Dim_ticket_preprocessed.csv"), index=False, encoding="utf-8-sig")
print(changelog.to_string()); print(); print(pd.DataFrame(checks).to_string()); print(); print(stop_summary.to_string())
